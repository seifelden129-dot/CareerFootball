plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.example.careermobile"; compileSdk = 35
 defaultConfig { applicationId = "com.example.careermobile"; minSdk = 23; targetSdk = 35; versionCode = 2; versionName = "1.1" } }
